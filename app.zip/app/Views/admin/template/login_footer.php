 <!-- Library Bundle Script -->
    <script src="<?php echo base_url();?>/assets/js/core/libs.min.js"></script>
    
    <!-- External Library Bundle Script -->
    <script src="<?php echo base_url();?>/assets/js/core/external.min.js"></script>
    
    <!-- Widgetchart Script -->
    <script src="<?php echo base_url();?>/assets/js/charts/widgetcharts.js"></script>
    
    <!-- mapchart Script -->
    <script src="<?php echo base_url();?>/assets/js/charts/vectore-chart.js"></script>
    <script src="<?php echo base_url();?>/assets/js/charts/dashboard.js" ></script>
    
    <!-- fslightbox Script -->
    <script src="<?php echo base_url();?>/assets/js/plugins/fslightbox.js"></script>
    
    <!-- Settings Script -->
    <script src="<?php echo base_url();?>/assets/js/plugins/setting.js"></script>
    
    <!-- Form Wizard Script -->
    <script src="<?php echo base_url();?>/assets/js/plugins/form-wizard.js"></script>
    
    <!-- AOS Animation Plugin-->
    
    <!-- App Script -->
    <script src="<?php echo base_url();?>/assets/js/hope-ui.js" defer></script>
	
	
