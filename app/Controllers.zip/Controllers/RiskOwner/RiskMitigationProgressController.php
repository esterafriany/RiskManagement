<?php

namespace App\Controllers\RiskOwner;
use App\Controllers\BaseController;
use Illuminate\Http\Request;

//Model
use App\Models\RiskMitigations;

class RiskMitigationProgressController extends BaseController
{
    public function index()
    {
        //
    }
}
