<div class="conatiner-fluid content-inner mt-n5 py-0">
	<div class="row">
      <div class="col-sm-12" style="padding-top:75px;">
         <div class="card">
            <div class="card-header d-flex justify-content-between">
               <div class="header-title">
                  <h4 class="card-title">Data User</h4>
               </div>
            </div>
            <div class="card-body">				
				 <div class="table-responsive" >
				 <table id="userTable" class="table table-striped">
				 <thead>
					<tr>
					   <th>Nama User</th>
					   <th>Email</th>
					   <th>Group</th>
					   <th>Status</th>
					   <th>Aksi</th>
					</tr>
				 </thead>
				</table>
                </div>
            </div>
         </div>
      </div>
   </div>
</div>

