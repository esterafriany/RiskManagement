<?php
if($content){
    echo view($content);
}
?>