      <!-- Footer Section Start -->
      <footer class="footer">
          <div class="footer-body">
              
              <div class="right-panel">
                  ©<script>document.write(new Date().getFullYear())</script>
                  </span> by <a href="perumppd.co.id">IT Dept Perum PPD</a>
              </div>
          </div>
      </footer>
      <!-- Footer Section End -->